## Criar campeonato
![criarcampeonato](https://github.com/HenriqueHuang/PPADS/assets/104871079/0f0f1181-b06a-4c87-858d-68125403d337)

https://drive.google.com/file/d/1hqZDUO3i-rDgrb5zodpiGhIc-TswuDo7/view?usp=sharing
Feito pelo Paulo
## Cancelar campeonato
![cancelar_campeonato](https://github.com/HenriqueHuang/PPADS/assets/104871079/eb9c9e44-d592-4b5c-8165-b1804d74d16b)

https://drive.google.com/file/d/1K38gXTNuweaUlO_QGEbrfsdHaktXNsPL/view?usp=sharing
Feito pelo Paulo
## Preencher formumlário
![preencherform](https://github.com/HenriqueHuang/PPADS/assets/104871079/e00ac1b3-3fd0-4261-80fd-177e01a8cc9b)

https://drive.google.com/file/d/1HjGOC9bLifz_a1bpAoIw9JcJZk-Djc_M/view?usp=sharing
Feito pelo Paulo
## Criar Unidade
![CriarUnidade](https://github.com/HenriqueHuang/PPADS/assets/99227897/d692e3f4-e4f4-4d55-adc0-ea669c4c5ead)
Feito pelo Henrique
## Modificar Unidade
![ModificarUnidade](https://github.com/HenriqueHuang/PPADS/assets/132959825/36fdf780-fade-4c96-8191-a0175e393090)
Feito pelo Leo
