![Diagrama de classes](https://github.com/HenriqueHuang/PPADS/assets/99227897/2ebf28ea-d721-4aec-b2d5-80a1e34253fe)
Feito pelo Henrique
