
![modelo_de_dominio](https://github.com/HenriqueHuang/PPADS/assets/99227897/0c065685-c3e2-4fc5-b2d2-22e4816a2a40)
Feito pelo Paulo
