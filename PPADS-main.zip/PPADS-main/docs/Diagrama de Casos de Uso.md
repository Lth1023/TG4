![Diagrama de Casos de Uso](https://github.com/HenriqueHuang/PPADS/assets/99227897/65d08500-2c4b-4ca5-ba8a-f3a5618dabd9)
