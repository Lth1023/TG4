[Definição de arquitetura.pdf](https://github.com/HenriqueHuang/PPADS/files/12528909/Definicao.de.arquitetura.pdf)
